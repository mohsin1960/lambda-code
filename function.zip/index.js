const { CognitoJwtVerifier } = require("aws-jwt-verify");

const verifier = CognitoJwtVerifier.create({
  userPoolId: "eu-south-1_S62DEE2P8",
  tokenUse: "id",
  clientId: "7ogrkq7t2nd3a7m4he1053l0kv",
});

const LOGIN_URL =
  "https://eu-south-1s62dee2p8.auth.eu-south-1.amazoncognito.com/login" +
  "?client_id=7ogrkq7t2nd3a7m4he1053l0kv" +
  "&response_type=token" +
  "&scope=openid+email+profile" +
  "&redirect_uri=https://intra.mgc.com.sa/callback";

exports.handler = async (event) => {
  const request = event.Records[0].cf.request;
  const headers = request.headers;
  const uri = request.uri;

  // Allow callback page through without checking token
  if (uri === "/callback" || uri === "/callback.html") {
    return request;
  }

  // Check for auth cookie
  const cookieHeader = headers.cookie?.[0]?.value || "";
  const tokenMatch = cookieHeader.match(/id_token=([^;]+)/);

  if (!tokenMatch) {
    return {
      status: "302",
      statusDescription: "Found",
      headers: {
        location: [{ key: "Location", value: LOGIN_URL }]
      }
    };
  }

  try {
    const payload = await verifier.verify(tokenMatch[1]);

    if (!payload.email?.endsWith("@mgc.com.sa")) {
      return { status: "403", statusDescription: "Forbidden", body: "Access denied. MGC accounts only." };
    }

    return request;
  } catch (e) {
    return {
      status: "302",
      statusDescription: "Found",
      headers: {
        location: [{ key: "Location", value: LOGIN_URL }]
      }
    };
  }
};
