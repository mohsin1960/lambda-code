const { CognitoJwtVerifier } = require("aws-jwt-verify");

const verifier = CognitoJwtVerifier.create({
  userPoolId: "eu-south-1_S62DEE2P8",
  tokenUse: "id",
  clientId: "7ogrkq7t2nd3a7m4he1053l0kv",
});

exports.handler = async (event) => {
  const request = event.Records[0].cf.request;
  const headers = request.headers;
  
  // Check for auth cookie
  const cookieHeader = headers.cookie?.[0]?.value || "";
  const tokenMatch = cookieHeader.match(/id_token=([^;]+)/);
  
  if (!tokenMatch) {
    // Redirect to Cognito login
    return {
      status: "302",
      headers: {
        location: [{
          key: "Location",
          value: "https://eu-south-1s62dee2p8.auth.eu-south-1.amazoncognito.com"
        }]
      }
    };
  }

  try {
    const payload = await verifier.verify(tokenMatch[1]);
    
    // Restrict to MGC email domain
    if (!payload.email?.endsWith("@mgc.com.sa")) {
      return { status: "403", body: "Access denied. MGC accounts only." };
    }
    
    return request; // Allow through
  } catch (e) {
    return { status: "302", headers: { location: [{ key: "Location", value: "/login" }] } };
  }
};
